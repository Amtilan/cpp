#include <bits/stdc++.h>

using namespace std; 

int main(){ 
    int w, h; 
    cin >> w >> h;

    int all_digits[w * h]; //double array

    for(int i = 0; i < w * h; i++) 
        cin >> all_digits[i]; 
    
    sort(all_digits, all_digits + w * h); //sort the array(first number of the array is minimum number and last number is maximum number)
    
    int max_array_of_digits [w][h], min_array_of_digits [w][h]; 
    int front = 0, back = w * h - 1; //front is the index of the maximum number and back is the index of the minimum number
    
    for(int i = 0; i < w; i++) 
        
        for(int j = 0; j < h; j++){ 
            if(j == h / 2) break; //h always divisible by 2 
            
            max_array_of_digits[i][j] = all_digits[back--]; //give the maximum number to the maximum number array 

            min_array_of_digits[i][j] = all_digits[front++]; //give the minimum number to the minimum number array 
        } 
    
    for(int i = 0; i < w; i++){ 
        for(int j = 0; j < h; j++){ 
            if(j == h / 2) break; 

            cout << max_array_of_digits[i][j] << " " << min_array_of_digits[i][j] << " "; 
        }

        cout << endl; 
    }
    return 0;     
}