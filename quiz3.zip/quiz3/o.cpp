#include <bits/stdc++.h>

using namespace std;

int main(){
    string s;
    cin >> s;
    sort(s.begin(), s.end());
    int max1 = 0;
    char f;
    for(auto c : s){
        if(f == c) continue;
        if(max1 < count(s.begin(), s.end(), c)){
            max1 = count(s.begin(), s.end(), c);
            f = c;
        }
    }
    cout << f << " " << max1 << endl;
    return 0;
}