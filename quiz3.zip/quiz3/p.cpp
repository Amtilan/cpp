#include <bits/stdc++.h>

using namespace std;

int main(){
    string s;
    cin >> s;
    if(s == '0') cout << "False";
    else if(s == "1") cout << "True";
    else cout << s;
    return 0;
}