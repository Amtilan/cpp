#include <bits/stdc++.h>

using namespace std;

int main(){
    string
    return 0;
}